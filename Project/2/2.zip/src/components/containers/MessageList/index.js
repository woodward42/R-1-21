import page from './MessageList.jsx';

export default page;