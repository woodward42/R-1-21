import page from './Message.jsx';

export default page;