import React from 'react';
// import ReactDom from 'react-dom';

import './style.scss';

export default () => {
    return <div>
        <input type="text"/>
        <button>Send</button>
    </div>;
};