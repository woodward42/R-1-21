import page from './MsgInput.jsx';

export default page;