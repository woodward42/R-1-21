import page from './Home.jsx';

export default page;

/*

Home
    MessageList //container
        Msg //comp
        Msg
        Msg
        Msg
        Msg
        Msg
    MessageInput //control
        input
        button
*/